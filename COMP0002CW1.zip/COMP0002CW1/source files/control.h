#pragma once
#include "robot.h"
#include "main.h"

void movingEverywhereRecurAbs(map *map, char **mapCopy, point curPos, robot *robot, char lookingFor);