#pragma once

int randomNumber(int min_num, int max_num);
enum dirs randomDir();
point randomEmptyPointOnMap(char **map, char empty, int width, int height);